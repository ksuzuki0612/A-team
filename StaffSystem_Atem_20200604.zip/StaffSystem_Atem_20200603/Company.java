import java.util.*;
import java.text.*;
import java.io.*;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.function.Supplier;
import java.util.logging.FileHandler;
import java.util.logging.Formatter;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class Company {
	static Logger logger = Logger.getLogger(Company.class.getName());
	static String url = "jdbc:mysql://localhost:3306/employee?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
    private List<Staff> staffs;
    List<Staff> list = new ArrayList<Staff>();
    private static boolean exit = false;
    //staff���̐���
    static int staffNum = 500;
    //�o�^���ꂽstaff�̐�
    static int registerNofStaff = 0;
    static String msg = "" ;
    
    public static String sqlMatomeCertiReward(){
        logger.entering(LogUtil.getClassName(), LogUtil.getMethodName());
        String sqlCertificate = "CONCAT (certificate1";
        String sqlRewardsPunishments = "CONCAT (rewardsPunishments1";
        for(int CR = 2 ; CR < 21 ; CR++){
            //���i�Əܔ��̗���""�ł͂Ȃ��ꍇ�A�u,�v�ŋ�؂��Ēl������������B��jJLPT N1, TOEIC 700
            sqlCertificate = sqlCertificate + ", if(certificate" + CR + " = '', '', CONCAT (',', certificate" + CR + "))";
            sqlRewardsPunishments = sqlRewardsPunishments + ", if(rewardsPunishments" + CR + " = '', '', CONCAT (',', rewardsPunishments" + CR + "))";
        }
        sqlCertificate += ") as certificate, ";
        sqlRewardsPunishments += ") as rewardsPunishments, ";
        String sqlMatome = "select emp_id, emp_name, emp_gender, birth, position, assignment, yearsWorked, " + sqlCertificate
         + sqlRewardsPunishments + "programmingLanguage FROM emp" ;
        return sqlMatome;
    }

    public Company() {
        logger.entering(LogUtil.getClassName(), LogUtil.getMethodName());
        staffs = new ArrayList<Staff>();
    }
    
    public  List<Staff> getAllStaffs(){
        logger.entering(LogUtil.getClassName(), LogUtil.getMethodName());
        return staffs;
    }
    public boolean getExist() {
        logger.entering(LogUtil.getClassName(), LogUtil.getMethodName());
        return exit;
    }

    //�]�ƈ��̓o�^
    public void addStaff(Staff staff, String userID, String password) {
        logger.entering(LogUtil.getClassName(), LogUtil.getMethodName());
        if(registerNofStaff < staffNum){
            this.staffs.add(staff);
            registerNofStaff++;
        }else{
            msg = staffNum + "�l�܂ł����ǉ��ł܂���B";
        }
   //     try {
   //         Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
   //         Connection conn = DriverManager.getConnection(url, userID, password);
   //         Statement stmt = conn.createStatement();
   //         ResultSet rs = stmt.executeQuery("INSERT INTO emp(emp_id, emp_name, emp_gender, birth, position, assignment, yearsWorked, programmingLanguage) VALUES(1234, 'Min', 'M', '1993-08-19', 'new', 'shinagawa', 1, 'java, C,,');");
   //         rs.close();
   //         stmt.close();
   //     }catch (ClassNotFoundException e){
   //       System.out.println("ClassNotFoundException:" + e.getMessage());
   //     }catch (SQLException e){
   //       System.out.println("SQLException:" + e.getMessage());
   //     }catch (Exception e){
   //       System.out.println("Exception:" + e.getMessage());
   //     }
    }
    
    //�]�ƈ��̍폜
    public void deleteStaff(int delete, String userID, String password) {
        logger.entering(LogUtil.getClassName(), LogUtil.getMethodName());
        exit = false;
        for(int i = 0 ; i < this.staffs.size() ; i++) {
          if(delete == this.staffs.get(i).getEmp_id()) {
              this.staffs.remove(i);
              exit = true;
          }
        }  
    }
    //�]�ƈ��̍X�V
    public void updateStaff(int updateID, Staff staff, String userID, String password) {
        logger.entering(LogUtil.getClassName(), LogUtil.getMethodName());
        deleteStaff(updateID, userID, password);
        addStaff(staff, userID, password);
    }
    
    public static void employeeView(String userID, String password){
        logger.entering(LogUtil.getClassName(), LogUtil.getMethodName());
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            Connection conn = DriverManager.getConnection(url, userID, password);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT emp_id, emp_name, emp_gender, position, assignment FROM emp;");
            System.out.println("iD    ���O       ����  ��E       ����");
            while(rs.next()){
                int emp_id = rs.getInt("emp_id");
                String emp_name = rs.getString("emp_name");
                String emp_gender = rs.getString("emp_gender");
                String position = rs.getString("position");
                String assignment = rs.getString("assignment");
                System.out.println(String.format("%-5s %-10s %-5s %-10s %-10s",emp_id, emp_name, emp_gender, position, assignment));
            }
            rs.close();
            stmt.close();
        }catch (Exception e){
          System.out.println("Exception:" + e.getMessage());
        }
    }
    
    public static void informationView(String userID, String password){
        logger.entering(LogUtil.getClassName(), LogUtil.getMethodName());
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            Connection conn = DriverManager.getConnection(url, userID, password);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sqlMatomeCertiReward() + ";");
            System.out.println("iD   ���O       ���� ���N����   ��E       ����       �Ζ��N�� ���i                                 �ܔ�                                 �v���O���~���O����");
            while(rs.next()){
                System.out.println(String.format("%-4s %-10s %-4s %-10s %-10s %-10s %-8s %-36s %-36s %-10s",
                rs.getInt(1), rs.getString(2), rs.getString(3), rs.getDate(4), rs.getString(5), rs.getString(6), rs.getInt(7), rs.getString(8), rs.getString(9), rs.getString(10)));
            }
            rs.close();
            stmt.close();
        }catch (Exception e){
          System.out.println("Exception:" + e.getMessage());
        }
    }
    
    public static void assignmentView(String userID, String password){
        logger.entering(LogUtil.getClassName(), LogUtil.getMethodName());
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            Connection conn = DriverManager.getConnection(url, userID, password);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT project.pj_id, project.pj_name, count(*) AS nofEmp FROM projectHistory LEFT JOIN project ON projectHistory.pj_id = project.pj_id GROUP BY emp_id;");
            System.out.println("ProjcetiD    Project��         �l��");
            while(rs.next()){
                int pj_id = rs.getInt("pj_id");
                String pj_name = rs.getString("pj_name");
                int nofEmp = rs.getInt("nofEmp");
                System.out.println(String.format("%-8s %-15s %-5s",pj_id, pj_name, nofEmp));
            }
            rs.close();
            stmt.close();
        }catch (Exception e){
          System.out.println("Exception:" + e.getMessage());
        }
    }
    
    public void searchByEmp_id(int emp_id, String userID, String password){
        logger.entering(LogUtil.getClassName(), LogUtil.getMethodName());
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            Connection conn = DriverManager.getConnection(url, userID, password);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sqlMatomeCertiReward() + " WHERE emp_id LIKE '%" + emp_id +"%';");
            while(rs.next()){
                System.out.println(String.format("%-7s %-7s %-3s %-12s %-15s %-15s %-5s %-50s %-50s %-20s"
                ,"id","name","gender","birth","position","assignment","yearsWorked","certificate","rewardsPunishments","programmingLanguage"));
                System.out.println(String.format("%-7s  %-7s %-3s %-12s %-15s %-15s %-5s %-50s %-50s %-20s",  rs.getInt(1), rs.getString(2), rs.getString(3), rs.getDate(4), rs.getString(5)
                 , rs.getString(6), rs.getInt(7), rs.getString(8), rs.getString(9), rs.getString(10)));
            }
            
            rs.close();
            stmt.close();
        }catch (Exception e){
          System.out.println("Exception:" + e.getMessage());
        }
    }
    
    public void searchByEmp_name(String emp_name, String userID, String password){
        logger.entering(LogUtil.getClassName(), LogUtil.getMethodName());
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            Connection conn = DriverManager.getConnection(url, userID, password);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sqlMatomeCertiReward() + " WHERE emp_name LIKE '%" + emp_name +"%';");
            while(rs.next()){
                System.out.println(String.format("%-7s %-7s %-3s %-12s %-15s %-15s %-5s %-50s %-50s %-20s"
                ,"id","name","gender","birth","position","assignment","yearsWorked","certificate","rewardsPunishments","programmingLanguage"));
                System.out.println(String.format("%-7s %-7s %-3s %-12s %-15s %-15s %-5s %-50s %-50s %-20s", rs.getInt(1), 
                	rs.getString(2), rs.getString(3), rs.getDate(4), rs.getString(5), rs.getString(6), rs.getInt(7), 
                    rs.getString(8), rs.getString(9), rs.getString(10)));
            }
            
            rs.close();
            stmt.close();
        }catch (Exception e){
          System.out.println("Exception:" + e.getMessage());
        }
    }
    
    public void searchByEmp_gender(char emp_gender, String userID, String password){
        logger.entering(LogUtil.getClassName(), LogUtil.getMethodName());
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            Connection conn = DriverManager.getConnection(url, userID, password);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sqlMatomeCertiReward() + " WHERE emp_gender LIKE '%" + emp_gender +"%';");
            while(rs.next()){
                System.out.println(String.format("%-7s %-7s %-3s %-12s %-15s %-15s %-5s %-50s %-50s %-20s"
                ,"id","name","gender","birth","position","assignment","yearsWorked","certificate","rewardsPunishments","programmingLanguage"));
                System.out.println(String.format("%-7s %-7s %-3s %-12s %-15s %-15s %-5s %-50s %-50s %-20s", rs.getInt(1), 
                	rs.getString(2), rs.getString(3), rs.getDate(4), rs.getString(5), rs.getString(6), rs.getInt(7), 
                    rs.getString(8), rs.getString(9), rs.getString(10)));
            }
            
            rs.close();
            stmt.close();
        }catch (Exception e){
          System.out.println("Exception:" + e.getMessage());
        }
    }
    
    public void searchByBirth(String birth, String userID, String password){
        logger.entering(LogUtil.getClassName(), LogUtil.getMethodName());
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            Connection conn = DriverManager.getConnection(url, userID, password);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sqlMatomeCertiReward() + " WHERE birth LIKE '%" + birth +"%';");
            while(rs.next()){
                System.out.println(String.format("%-7s %-7s %-3s %-12s %-15s %-15s %-5s %-50s %-50s %-20s"
                ,"id","name","gender","birth","position","assignment","yearsWorked","certificate","rewardsPunishments","programmingLanguage"));
                System.out.println(String.format("%-7s %-7s %-3s %-12s %-15s %-15s %-5s %-50s %-50s %-20s", rs.getInt(1), 
                	rs.getString(2), rs.getString(3), rs.getDate(4), rs.getString(5), rs.getString(6), rs.getInt(7), 
                    rs.getString(8), rs.getString(9), rs.getString(10)));
            }
            
            rs.close();
            stmt.close();
        }catch (Exception e){
          System.out.println("Exception:" + e.getMessage());
        }
    }
    
    public void searchByPosition(String position, String userID, String password){
        logger.entering(LogUtil.getClassName(), LogUtil.getMethodName());
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            Connection conn = DriverManager.getConnection(url, userID, password);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sqlMatomeCertiReward() + " WHERE position LIKE '%" + position +"%';");
            while(rs.next()){
                System.out.println(String.format("%-7s %-7s %-3s %-12s %-15s %-15s %-5s %-50s %-50s %-20s"
                ,"id","name","gender","birth","position","assignment","yearsWorked","certificate","rewardsPunishments","programmingLanguage"));
                System.out.println(String.format("%-7s %-7s %-3s %-12s %-15s %-15s %-5s %-50s %-50s %-20s", rs.getInt(1), 
                	rs.getString(2), rs.getString(3), rs.getDate(4), rs.getString(5), rs.getString(6), rs.getInt(7), 
                    rs.getString(8), rs.getString(9), rs.getString(10)));
            }
            
            rs.close();
            stmt.close();
        }catch (Exception e){
          System.out.println("Exception:" + e.getMessage());
        }
    }
    
    public void searchByAssignment(String assignment, String userID, String password){
        logger.entering(LogUtil.getClassName(), LogUtil.getMethodName());
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            Connection conn = DriverManager.getConnection(url, userID, password);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sqlMatomeCertiReward() + " WHERE assignment LIKE '%" + assignment +"%';");
            while(rs.next()){
                System.out.println(String.format("%-7s %-7s %-3s %-12s %-15s %-15s %-5s %-50s %-50s %-20s"
                ,"id","name","gender","birth","position","assignment","yearsWorked","certificate","rewardsPunishments","programmingLanguage"));
                System.out.println(String.format("%-7s %-7s %-3s %-12s %-15s %-15s %-5s %-50s %-50s %-20s", rs.getInt(1), 
                	rs.getString(2), rs.getString(3), rs.getDate(4), rs.getString(5), rs.getString(6), rs.getInt(7), 
                    rs.getString(8), rs.getString(9), rs.getString(10)));
            }
            
            rs.close();
            stmt.close();
        }catch (Exception e){
          System.out.println("Exception:" + e.getMessage());
        }
    }
    
    public void searchByYearsWorked(int yearsWorked, String userID, String password){
        logger.entering(LogUtil.getClassName(), LogUtil.getMethodName());
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            Connection conn = DriverManager.getConnection(url, userID, password);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sqlMatomeCertiReward() + " WHERE yearsWorked LIKE '%" + yearsWorked +"%';");
            while(rs.next()){
                System.out.println(String.format("%-7s %-7s %-3s %-12s %-15s %-15s %-5s %-50s %-50s %-20s"
                ,"id","name","gender","birth","position","assignment","yearsWorked","certificate","rewardsPunishments","programmingLanguage"));
                System.out.println(String.format("%-7s %-7s %-3s %-12s %-15s %-15s %-5s %-50s %-50s %-20s", rs.getInt(1), 
                	rs.getString(2), rs.getString(3), rs.getDate(4), rs.getString(5), rs.getString(6), rs.getInt(7), 
                    rs.getString(8), rs.getString(9), rs.getString(10)));
            }
            
            rs.close();
            stmt.close();
        }catch (Exception e){
          System.out.println("Exception:" + e.getMessage());
        }
    }
    
    public void searchByCertificate(String certificate, String userID, String password){
        logger.entering(LogUtil.getClassName(), LogUtil.getMethodName());
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            Connection conn = DriverManager.getConnection(url, userID, password);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sqlMatomeCertiReward() + ";");
            while(rs.next()){
                if(rs.getString(8).contains(certificate)){
                    System.out.println(String.format("%-7s %-7s %-3s %-12s %-15s %-15s %-5s %-50s %-50s %-20s"
                    ,"id","name","gender","birth","position","assignment","yearsWorked","certificate","rewardsPunishments","programmingLanguage"));
                    System.out.println(String.format("%-7s %-7s %-3s %-12s %-15s %-15s %-5s %-50s %-50s %-20s", rs.getInt(1), 
                	rs.getString(2), rs.getString(3), rs.getDate(4), rs.getString(5), rs.getString(6), rs.getInt(7), 
                    rs.getString(8), rs.getString(9), rs.getString(10)));
                }
            }
            
            rs.close();
            stmt.close();
        }catch (Exception e){
          System.out.println("Exception:" + e.getMessage());
        }
    }
    
    public void searchByRewardsPunishments(String rewardsPunishments, String userID, String password){
        logger.entering(LogUtil.getClassName(), LogUtil.getMethodName());
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            Connection conn = DriverManager.getConnection(url, userID, password);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sqlMatomeCertiReward() + ";");
            while(rs.next()){
                if(rs.getString(9).contains(rewardsPunishments)){
                    System.out.println(String.format("%-7s %-7s %-3s %-12s %-15s %-15s %-5s %-50s %-50s %-20s"
                    ,"id","name","gender","birth","position","assignment","yearsWorked","certificate","rewardsPunishments","programmingLanguage"));
                    System.out.println(String.format("%-7s %-7s %-3s %-12s %-15s %-15s %-5s %-50s %-50s %-20s", rs.getInt(1), 
                	rs.getString(2), rs.getString(3), rs.getDate(4), rs.getString(5), rs.getString(6), rs.getInt(7), 
                    rs.getString(8), rs.getString(9), rs.getString(10)));
                }
            }
            
            rs.close();
            stmt.close();
        }catch (Exception e){
          System.out.println("Exception:" + e.getMessage());
        }
    }
    
    public void searchByProgrammingLanguage(String programmingLanguage, String userID, String password){
        logger.entering(LogUtil.getClassName(), LogUtil.getMethodName());
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            Connection conn = DriverManager.getConnection(url, userID, password);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sqlMatomeCertiReward() + " WHERE programmingLanguage LIKE '%" + programmingLanguage +"%';");
            while(rs.next()){
                System.out.println(String.format("%-7s %-7s %-3s %-12s %-15s %-15s %-5s %-50s %-50s %-20s"
                ,"id","name","gender","birth","position","assignment","yearsWorked","certificate","rewardsPunishments","programmingLanguage"));
                System.out.println(String.format("%-7s %-7s %-3s %-12s %-15s %-15s %-5s %-50s %-50s %-20s", rs.getInt(1), 
                	rs.getString(2), rs.getString(3), rs.getDate(4), rs.getString(5), rs.getString(6), rs.getInt(7), 
                    rs.getString(8), rs.getString(9), rs.getString(10)));
            }
            
            rs.close();
            stmt.close();
        }catch (ClassNotFoundException e){
          System.out.println("ClassNotFoundException:" + e.getMessage());
        }catch (SQLException e){
          System.out.println("SQLException:" + e.getMessage());
        }catch (Exception e){
          System.out.println("Exception:" + e.getMessage());
        }
        logger.exiting(LogUtil.getClassName(), LogUtil.getMethodName());
    }
}
