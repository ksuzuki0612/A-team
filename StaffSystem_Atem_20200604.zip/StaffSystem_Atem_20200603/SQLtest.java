import java.sql.*;  //Package for SQL connection

public class SQLtest{
    public static void main(String []args){ 
        //URL, Username, Password, query setup.
        
        try{
            String url = "jdbc:mysql://localhost:3306/employee?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
            String userName = "root";
            String pwd = "password1234";
            String query = "SELECT * FROM emp";

            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(url, userName, pwd); //Obtains connection to DB
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(query);  //Statement and Result model data result sets and SQL statements.
        
            rs.next();
            String emp_id = rs.getString("emp_id");
            String emp_name = rs.getString("emp_name");
        
            System.out.println(emp_id);
            System.out.println(emp_name);

            st.close();
            con.close();
            }catch(Exception e) { System.out.println(e);}  


    }
}


